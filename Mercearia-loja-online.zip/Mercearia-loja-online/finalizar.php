<?php
include 'db.php';
session_start();

$itens = $_POST['qtd'] ?? [];
$total = 0;
$compra = [];

foreach ($itens as $id => $qtd) {
    $id = intval($id);
    $qtd = intval($qtd);
    if ($qtd <= 0) continue;

    $res = $conn->query("SELECT * FROM produtos WHERE id = $id");
    $prod = $res->fetch_assoc();
    if ($prod['quantidade'] == 0) die("Produto {$prod['nome']} esgotado.");
    if ($qtd > $prod['quantidade']) die("Quantidade excede o estoque de {$prod['nome']}.");

    $total += $qtd * $prod['preco'];
    $compra[] = ["id" => $id, "nome" => $prod['nome'], "qtd" => $qtd];
}

$_SESSION['carrinho'] = $compra;
$_SESSION['total'] = $total;
header("Location: formulario.php");
exit;