<?php session_start(); ?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Finalizar Encomenda</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            height: 100vh;
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #ece9e6, #ffffff);
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .form-container {
            background: white;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 450px;
        }

        .form-container h2 {
            margin-bottom: 25px;
            color: #2b4c7e;
            text-align: center;
            font-size: 24px;
        }

        label {
            display: block;
            margin-bottom: 15px;
            font-weight: 500;
            color: #333;
        }

        input[type="text"],
        input[type="date"] {
            width: 100%;
            padding: 12px;
            font-size: 16px;
            border-radius: 8px;
            border: 1px solid #ccc;
            margin-top: 5px;
        }

        input[type="submit"] {
            width: 100%;
            padding: 14px;
            background-color: #2b4c7e;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            margin-top: 20px;
            transition: background 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #1f355e;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Finalizar Encomenda</h2>
        <form action="concluir.php" method="POST">
            <label>
                Nome:
                <input name="nome" type="text" required>
            </label>
            <label>
                Data de nascimento:
                <input name="nasc" type="date" required>
            </label>
            <label>
                Morada:
                <input name="morada" type="text" required>
            </label>
            <input type="submit" value="Finalizar Encomenda">
        </form>
    </div>
</body>
</html>
