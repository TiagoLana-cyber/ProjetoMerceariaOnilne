<?php
session_start();
include 'db.php';
if (!isset($_SESSION['admin'])) die("Acesso negado.");


$msg = $_SESSION['msg'] ?? '';
unset($_SESSION['msg']);

// Deletar produto
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $stmt = $conn->prepare("DELETE FROM produtos WHERE id = ?");
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        $_SESSION['msg'] = "Produto excluído com sucesso.";
    } else {
        $_SESSION['msg'] = "Erro ao excluir produto.";
    }
    header("Location: admin.php");
    exit;
}

// Atualizar produto
if (isset($_POST['update_id'])) {
    $id = intval($_POST['update_id']);
    $nome = $_POST['nome'];
    $qtd = $_POST['qtd'];
    $preco = $_POST['preco'];

    $stmt = $conn->prepare("UPDATE produtos SET nome = ?, quantidade = ?, preco = ? WHERE id = ?");
    $stmt->bind_param("sidi", $nome, $qtd, $preco, $id);
    if ($stmt->execute()) {
        $_SESSION['msg'] = "Produto atualizado com sucesso.";
    } else {
        $_SESSION['msg'] = "Erro ao atualizar produto.";
    }
    header("Location: admin.php");
    exit;
}

// Adicionar novo produto
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['update_id'])) {
    $n = $_POST['nome'];
    $q = $_POST['qtd'];
    $p = $_POST['preco'];
    $img_path = '';

    if (isset($_FILES['img']) && $_FILES['img']['error'] === 0) {
        $upload_dir = "uploads/";
        if (!is_dir($upload_dir)) mkdir($upload_dir);

        $check = getimagesize($_FILES['img']['tmp_name']);
        if ($check !== false) {
            $filename = basename($_FILES['img']['name']);
            $target = $upload_dir . time() . '_' . $filename;
            if (move_uploaded_file($_FILES['img']['tmp_name'], $target)) {
                $img_path = $target;
            }
        } else {
            $_SESSION['msg'] = "Arquivo enviado não é uma imagem válida.";
            header("Location: admin.php");
            exit;
        }
    }

    $stmt = $conn->prepare("INSERT INTO produtos (nome, quantidade, preco, imagem) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("sids", $n, $q, $p, $img_path);
    if ($stmt->execute()) {
        $_SESSION['msg'] = "Produto adicionado com sucesso.";
    } else {
        $_SESSION['msg'] = "Erro ao adicionar produto.";
    }
    header("Location: admin.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Administração</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="container">
    <h1>Administração</h1>

    <div style="text-align: center; margin: 20px 0;">
    <a href="index.php" style="
        display: inline-block;
        background: #2b4c7e;
        color: white;
        padding: 12px 24px;
        text-decoration: none;
        border-radius: 8px;
        font-weight: bold;
        box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        transition: background 0.3s ease;
    ">
        ⬅ Voltar para Mercearia Brasil
    </a>
</div>

    <?php if ($msg): ?>
        <p style="color: green;"><strong><?= htmlspecialchars($msg) ?></strong></p>
    <?php endif; ?>

    <h2>Encomendas</h2>
    <ul>
    <?php
    $res = $conn->query("SELECT * FROM encomendas");
    while ($e = $res->fetch_assoc()) {
        $nome = htmlspecialchars($e['nome']);
        $total = number_format($e['total'], 2, ',', '.');
        echo "<li><strong>$nome</strong> - $total €</li>";
    }
    ?>
    </ul>

    <h2>Adicionar Novo Produto</h2>
    <form method="POST" enctype="multipart/form-data">
        Nome: <input name="nome" required>
        Quantidade: <input name="qtd" type="number" required>
        Preço: <input name="preco" type="number" step="0.01" required>
        Imagem: <input type="file" name="img" accept="image/*">
        <input type="submit" value="Adicionar">
    </form>

    <h2>Editar Produtos Existentes</h2>
    <table border="1" cellpadding="5">
        <tr><th>Nome</th><th>Qtd</th><th>Preço</th><th>Ações</th></tr>
        <?php
        $res = $conn->query("SELECT * FROM produtos");
        while ($p = $res->fetch_assoc()) {
            $id = $p['id'];
            $nome = htmlspecialchars($p['nome']);
            $qtd = (int)$p['quantidade'];
            $preco = number_format($p['preco'], 2, '.', '');

            echo "<tr>
                <form method='POST'>
                    <td><input name='nome' value='$nome'></td>
                    <td><input name='qtd' type='number' value='$qtd'></td>
                    <td><input name='preco' type='number' step='0.01' value='$preco'></td>
                    <td>
                        <input type='hidden' name='update_id' value='$id'>
                        <input type='submit' value='Atualizar'>
                        <a href='admin.php?delete=$id' onclick=\"return confirm('Tem certeza que deseja excluir este produto?')\">Excluir</a>
                    </td>
                </form>
            </tr>";
        }
        ?>
    </table>
</div>
</body>
</html>
