function atualizarTotal() {
    let total = 0;
    document.querySelectorAll("input[type='number']").forEach(inp => {
        let qtd = parseFloat(inp.value);
        let preco = parseFloat(inp.parentElement.previousElementSibling.textContent.replace('€', ''));
        total += qtd * preco;
    });
    document.getElementById("total").textContent = total.toFixed(2);

    
}