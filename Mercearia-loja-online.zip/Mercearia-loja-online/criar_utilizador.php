<?php
include 'db.php';

$username = 'admin';
$password = password_hash('admin123', PASSWORD_DEFAULT);

$stmt = $conn->prepare("INSERT INTO utilizadores (username, password) VALUES (?, ?)");
$stmt->bind_param("ss", $username, $password);

if ($stmt->execute()) {
    echo "Utilizador criado com sucesso.";
} else {
    echo "Erro ao criar utilizador: " . $stmt->error;
}
?>
