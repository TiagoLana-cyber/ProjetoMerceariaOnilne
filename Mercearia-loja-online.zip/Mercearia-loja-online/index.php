<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Mercearia Brasil</title>
  <link rel="stylesheet" href="css/style.css?v=1.1">

    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <style>
        
.paginacao {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 10px;
    margin-top: 30px;
    flex-wrap: wrap;
}

.paginacao button {
    background-color: #28a745; /* verde chamativo */
    color: white;
    border: none;
    padding: 10px 20px;
    font-size: 16px;
    font-weight: bold;
    border-radius: 8px;
    cursor: pointer;
    transition: background-color 0.3s ease, transform 0.2s ease;
    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
}

.paginacao button:hover {
    background-color: #218838;
    transform: scale(1.05);
}

.paginacao button:disabled {
    background-color: #ccc;
    cursor: not-allowed;
    color: #666;
    transform: none;
}

.paginacao span#pagina-atual {
    font-size: 16px;
    font-weight: 600;
    padding: 6px 12px;
    background-color: #f8f9fa;
    border-radius: 6px;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.1);
}

    </style>
</head>
<body>


<div class="sidebar">
    <div class="menu-item"><a href="index.php"><i class="fas fa-home"></i><span>Início</span></a></div>
    <div class="menu-item"><a href="#produtos"><i class="fas fa-boxes"></i><span>Produtos</span></a></div>
    <div class="menu-item"><a href="login.php"><i class="fas fa-lock"></i><span>Login</span></a></div>
</div>


<div class="container">
    <h1><i class="fas fa-shopping-cart"></i> Mercearia Brasil</h1>
   <div class="busca-wrapper">
    <i class="fas fa-search lupa-icon"></i>
    <input type="text" id="busca" placeholder="Buscar produtos..." onkeyup="filtrarProdutos()" />
</div>

    <form id="carrinho" method="POST" action="finalizar.php">
        <div class="grid" id="produtos">
            <?php
            $result = $conn->query("SELECT * FROM produtos");
            while($row = $result->fetch_assoc()) {
                $img = $row['imagem'] ? $row['imagem'] : 'https://via.placeholder.com/150';
                echo "<div class='produto'>";
                echo "<img class='produto-img' src='{$img}' alt='{$row['nome']}'>";
                echo "<div class='produto-info'>";
                echo "<h3>{$row['nome']}</h3>";
                echo "<p>Preço: €{$row['preco']}<br>Disponível: {$row['quantidade']}</p>";
                echo "<input type='number' class='quantidade' name='qtd[{$row['id']}]' 
                        min='0' max='{$row['quantidade']}' value='0' 
                        data-preco='{$row['preco']}' onchange='atualizarTotal()'>";
                echo "</div></div>";
            }
            ?>
        </div>

        <div class="paginacao">
    <button onclick="paginaAnterior()">Anterior</button>
    <span id="pagina-atual">1</span>
    <button onclick="proximaPagina()">Próximo</button>
</div>

        <p class="total">Total: <span id="total">0.00</span> €</p>
        <button type="submit"><i class="fas fa-credit-card"></i> Concluir Compra</button>
    </form>
</div>


<div class="comercial-lateral">
    <p>🛒 Promoção da Semana!</p>
    <strong>Arroz 5kg por apenas €3.99!</strong>
    <a href="javascript:void(0);" class="btn-oferta" onclick="buscarProduto('arroz 5kg')">Confira</a>

</div>


<!-- Rodapé -->
<footer class="footer">
    <div class="social-icons">
        <a href="https://facebook.com" target="_blank" title="Facebook"><i class="fab fa-facebook-f"></i></a>
        <a href="https://instagram.com" target="_blank" title="Instagram"><i class="fab fa-instagram"></i></a>
        <a href="https://twitter.com" target="_blank" title="Twitter"><i class="fab fa-twitter"></i></a>
        <a href="https://wa.me/5599999999999" target="_blank" title="WhatsApp"><i class="fab fa-whatsapp"></i></a>
    </div>
    <p>© 2025 Mercearia Brasil. Todos os direitos reservados.</p>
</footer>


<script>
function filtrarProdutos() {
    const termo = document.getElementById('busca').value.toLowerCase();
    const produtos = document.querySelectorAll('.produto');
    produtos.forEach(p => {
        const nome = p.querySelector('h3').textContent.toLowerCase();
        p.style.display = nome.includes(termo) ? 'block' : 'none';
    });
}

function atualizarTotal() {
    let total = 0;
    const inputs = document.querySelectorAll('.quantidade');
    inputs.forEach(input => {
        const qtd = parseFloat(input.value);
        const preco = parseFloat(input.dataset.preco);
        if (!isNaN(qtd) && !isNaN(preco)) {
            total += qtd * preco;
        }
    });
    document.getElementById('total').innerText = total.toFixed(2);
}

function buscarProduto(produto) {
    const campoBusca = document.getElementById('busca');
    campoBusca.value = produto;
    filtrarProdutos();
    document.getElementById('produtos').scrollIntoView({ behavior: 'smooth' });
}


let paginaAtual = 1;
const itensPorPagina = 12;

function paginarProdutos() {
    const produtos = document.querySelectorAll('.produto');
    const totalProdutos = produtos.length;
    const totalPaginas = Math.ceil(totalProdutos / itensPorPagina);

    // Atualizar texto da página atual
    document.getElementById('pagina-atual').innerText = `${paginaAtual} / ${totalPaginas}`;

    produtos.forEach((produto, index) => {
        const inicio = (paginaAtual - 1) * itensPorPagina;
        const fim = inicio + itensPorPagina;
        if (index >= inicio && index < fim) {
            produto.style.display = 'block';
        } else {
            produto.style.display = 'none';
        }
    });

    // Ativar/desativar botões
    document.querySelector('.paginacao button:first-child').disabled = (paginaAtual === 1);
    document.querySelector('.paginacao button:last-child').disabled = (paginaAtual === totalPaginas);
}

function paginaAnterior() {
    if (paginaAtual > 1) {
        paginaAtual--;
        paginarProdutos();
    }
}

function proximaPagina() {
    const produtos = document.querySelectorAll('.produto');
    const totalPaginas = Math.ceil(produtos.length / itensPorPagina);
    if (paginaAtual < totalPaginas) {
        paginaAtual++;
        paginarProdutos();
    }
}

// Inicializar paginação ao carregar
window.addEventListener('load', () => {
    paginarProdutos();
});



</script>

</body>
</html>
