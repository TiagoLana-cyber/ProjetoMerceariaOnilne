CREATE DATABASE IF NOT EXISTS mercearia;
USE mercearia;

CREATE TABLE produtos (
    imagem VARCHAR(255),
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100),
    quantidade INT,
    preco DECIMAL(10,2)
);

CREATE TABLE utilizadores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50),
    password VARCHAR(255)
);

CREATE TABLE encomendas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100),
    data_nascimento DATE,
    morada TEXT,
    produtos TEXT,
    total DECIMAL(10,2)
);

-- Admin com senha 'admin123'
INSERT INTO utilizadores (username, password) VALUES (
    'admin',
    'admin123'
);