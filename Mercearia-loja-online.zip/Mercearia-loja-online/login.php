<?php
session_start();
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $u = $_POST['username'] ?? '';
    $p = $_POST['password'] ?? '';

    $stmt = $conn->prepare("SELECT * FROM utilizadores WHERE username = ?");
    $stmt->bind_param("s", $u);
    $stmt->execute();
    $res = $stmt->get_result();
    $user = $res->fetch_assoc();

    if ($user && password_verify($p, $user['password'])) {
        $_SESSION['admin'] = true;
        header("Location: admin.php");
        exit;
    } else {
        $erro = "Credenciais inválidas.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Login | Mercearia Brasil</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            height: 100vh;
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(-45deg, #1f1c2c, #928dab, #2b5876, #4e4376);
            background-size: 400% 400%;
            animation: gradient 10s ease infinite;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        @keyframes gradient {
            0% {background-position: 0% 50%;}
            50% {background-position: 100% 50%;}
            100% {background-position: 0% 50%;}
        }

        .login-box {
            background: rgba(255, 255, 255, 0.95);
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            width: 100%;
            max-width: 400px;
            text-align: center;
        }

        .login-box h2 {
            margin-bottom: 20px;
            color: #2b4c7e;
        }

        .login-box input {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border-radius: 8px;
            border: 1px solid #ccc;
            font-size: 16px;
        }

        .login-box input[type="submit"] {
            background-color: #2b4c7e;
            color: white;
            border: none;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .login-box input[type="submit"]:hover {
            background-color: #1f355e;
        }

        .erro {
            color: red;
            margin-bottom: 15px;
            font-weight: bold;
        }

        .btn-voltar {
    display: inline-block;
    margin-top: 20px;
    padding: 10px 20px;
    background-color: #e0e0e0;
    color: #2b4c7e;
    font-weight: bold;
    border-radius: 8px;
    text-decoration: none;
    font-size: 16px;
    transition: background 0.3s ease, transform 0.2s ease;
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}

.btn-voltar:hover {
    background-color: #d0d0d0;
    transform: scale(1.03);
    text-decoration: none;
}

    </style>
</head>
<body>
    <div class="login-box">
        <h2>Login Administrativo</h2>
        <?php if (isset($erro)) echo "<p class='erro'>$erro</p>"; ?>
        <form method="POST">
            <input name="username" placeholder="Usuário" required>
            <input name="password" type="password" placeholder="Senha" required>
            <input type="submit" value="Entrar">
        </form>
        <a href="index.php" class="btn-voltar">
    &#8592; Voltar para Mercearia Brasil</a>


    </div>
</body>
</html>
