<?php
include 'db.php';
session_start();

function idade($data) {
    $nasc = new DateTime($data);
    $hoje = new DateTime();
    return $nasc->diff($hoje)->y;
}

$nome = htmlspecialchars($_POST['nome']);
$nasc = $_POST['nasc'];
$morada = htmlspecialchars($_POST['morada']);

if (!$nome || !$nasc || !$morada) die("Todos os campos são obrigatórios.");
if (idade($nasc) < 18) die("É necessário ter 18 anos ou mais.");

$produtos = json_encode($_SESSION['carrinho']);
$total = $_SESSION['total'];

$conn->query("INSERT INTO encomendas (nome, data_nascimento, morada, produtos, total) VALUES (
    '$nome', '$nasc', '$morada', '$produtos', '$total')");

foreach ($_SESSION['carrinho'] as $item) {
    $conn->query("UPDATE produtos SET quantidade = quantidade - {$item['qtd']} WHERE id = {$item['id']}");
}

session_destroy();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Encomenda Concluída</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f3f3f3;
            text-align: center;
            padding: 60px;
        }
        .mensagem {
            background-color: #d4edda;
            color: #155724;
            border: 2px solid #c3e6cb;
            padding: 20px;
            border-radius: 8px;
            max-width: 500px;
            margin: 0 auto 30px;
            font-size: 20px;
        }
        .btn-voltar {
            padding: 12px 25px;
            font-size: 16px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 6px;
            text-decoration: none;
            transition: 0.3s;
        }
        .btn-voltar:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <div class="mensagem">
        ✅ Encomenda realizada com sucesso!
    </div>
    <a href="index.php" class="btn-voltar">Voltar ao Início</a>
</body>
</html>