<?php
$host = 'localhost:3306';  
$user = 'root';
$db = 'mercearia';

$conn = new mysqli(hostname: $host, username: $user, database: $db);
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}
?>
